package com.example.textswapping;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.textswapping.R;

public class MainActivity extends AppCompatActivity {

    // Declare your views
    private EditText editText1, editText2;
    private Button swapButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize your views
        editText1 = findViewById(R.id.editText1);
        editText2 = findViewById(R.id.editText2);
        swapButton = findViewById(R.id.swapButton);

        // Set an OnClickListener to handle the button click
        swapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                swapTexts();
            }
        });
    }

    // This method swaps the texts in the EditTexts
    private void swapTexts() {
        String temp = editText1.getText().toString();
        editText1.setText(editText2.getText().toString());
        editText2.setText(temp);
    }
}
